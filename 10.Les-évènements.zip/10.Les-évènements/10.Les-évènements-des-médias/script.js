/* 
    On peut intégrer de la musique et des vidéos à l'aide des éléments <audio> et <video>.
    Ces élèments peuvent réagir à énormement d'évènements en rapport avec ces éléments.

    Découvrons ensemble : pause, play, loadeddata, playing, progress, etc...
*/



/* 
    Même combat pour l'élément <audio>.
*/

