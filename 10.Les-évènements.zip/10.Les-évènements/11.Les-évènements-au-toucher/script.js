/*
    Les "touch events" permettent de prendre en compte le "clic" d'un doigt sur un écran tactile.
*/

