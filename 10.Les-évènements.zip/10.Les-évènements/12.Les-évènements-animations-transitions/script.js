/*
    Il existe des évènements utiles avec les animations et les transitions.

    Transitions : transitionend, transitioncancel, transitionend, transitionrun, transitionstart

    Animation : animationstart, animationend
*/

