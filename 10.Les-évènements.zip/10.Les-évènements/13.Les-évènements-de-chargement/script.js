/*
    Voici les évènements concernant le chargement d'une page : DOMContentLoaded, load.
*/
