/* 
    Certains éléments ont déjà des écouteurs d'évènement par défaut et vont donc avoir un comportement spécial quand on les déclenche.

    Les formulaires vont tenter d'envoyer les données vers une page.

    Les liens nous font nous déplacer au click.

    Parfois, on a envie de prévenir ces comportements par défaut, on utilisera alors EventObject.preventDefault().

    Testons tout ça...
*/
