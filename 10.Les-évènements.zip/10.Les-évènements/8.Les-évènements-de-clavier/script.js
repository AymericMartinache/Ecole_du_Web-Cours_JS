/* 
    Les évènements de clavier peuvent nous permettre de connaître les touches pressées, ce qui peut être très utile dans de nombreux cas.
*/
