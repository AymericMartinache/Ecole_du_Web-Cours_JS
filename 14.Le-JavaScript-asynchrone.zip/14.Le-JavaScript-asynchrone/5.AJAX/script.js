/*
    AJAX veut dire : Asynchronous JavaScript And XML.
    
    C'est une fonctionnalité permettant d'envoyer des requêtes vers un serveur et de recevoir des données alors que la page a déjà chargé. 

    On va donc pouvoir envoyer et recevoir des données sans actualiser la page.
*/

/*
    Voici l'ancienne façon de faire, on utilise aujourd'hui la méthode fetch() qui est plus simple à utiliser mais qui utilise XMLHttpRequest sous le capot.
*/

