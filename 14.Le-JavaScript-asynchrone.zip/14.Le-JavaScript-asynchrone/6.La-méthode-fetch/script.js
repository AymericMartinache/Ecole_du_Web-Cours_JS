/* Découvrons la méthode fetch en JavaScript */

